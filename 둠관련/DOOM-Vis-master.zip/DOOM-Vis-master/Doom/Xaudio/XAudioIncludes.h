//------------------------------------------------------------
// DOOM port and BSP visualization by Daniel Fetter (2013-14)
//------------------------------------------------------------
#pragma once

#include "../Audio/AudioIncludes.h"

#include "XaDefs.h"
#include "XaVoiceCallback.h"
#include "XaSourceVoice.h"
#include "XAudio.h"
