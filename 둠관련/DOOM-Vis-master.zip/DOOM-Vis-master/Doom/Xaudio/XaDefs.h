//------------------------------------------------------------
// DOOM port and BSP visualization by Daniel Fetter (2013-14)
//------------------------------------------------------------
#pragma once

struct XaGlobal
{
	ComPtr<IXAudio2> xAudio;
};
