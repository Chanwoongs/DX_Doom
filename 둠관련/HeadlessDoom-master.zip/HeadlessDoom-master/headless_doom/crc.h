#ifndef CRC_H
#define CRC_H

unsigned
crc32_8bytes (const void *data, unsigned length, unsigned previousCrc32);

#endif

